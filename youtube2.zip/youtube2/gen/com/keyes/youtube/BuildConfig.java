/** Automatically generated file. DO NOT MODIFY */
package com.keyes.youtube;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}